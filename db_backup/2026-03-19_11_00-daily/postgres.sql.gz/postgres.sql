--
-- PostgreSQL database dump
--

\restrict PxFb4TP2jcm5dauq32gfBdC6NJ95wogoEGlhRHj4uFGFCDDs9it2ywcBd4zSY5K

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.3 (Ubuntu 18.3-1.pgdg25.10+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict PxFb4TP2jcm5dauq32gfBdC6NJ95wogoEGlhRHj4uFGFCDDs9it2ywcBd4zSY5K

